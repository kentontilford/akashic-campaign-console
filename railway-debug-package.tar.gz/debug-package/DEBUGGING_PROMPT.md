# Railway Deployment Debugging Task

## Context
You are debugging a Next.js 14 application with Prisma ORM that is failing to deploy on Railway. The application uses PostgreSQL (via Supabase) and optional Redis. The main issue is that health checks are failing during deployment, preventing the app from starting successfully.

## Current Deployment Errors
1. **EBUSY errors** during npm install (cache conflicts with Railway's Docker cache mounts)
2. **Health check timeouts** - The `/api/health` endpoint times out or returns 503
3. **Database connection failures** - Prisma can't connect during startup
4. **Environment variable issues** - Variables might not be available during build/startup

## Technical Stack
- Next.js 14 (App Router)
- Prisma ORM with PostgreSQL
- Redis (optional, for caching)
- NextAuth for authentication
- TypeScript
- Railway for deployment

## Your Task
Fix the deployment issues while maintaining the following principles:

### 1. Database Connection Resilience
- Add retry logic to Prisma client initialization
- Ensure the app can start even if the database is temporarily unavailable
- Use connection pooling efficiently
- Don't create new Prisma clients in API routes

### 2. Health Check Requirements
- Health checks should return 200 during startup grace period (first 60 seconds)
- After grace period, return accurate status (503 if unhealthy)
- Don't create new database connections just for health checks
- Handle optional services (Redis) gracefully

### 3. Environment Variables
- Handle missing environment variables gracefully during build
- Ensure required variables are validated at runtime, not import time
- Support Railway's environment variable injection timing

### 4. Build Process
- Ensure the Dockerfile works with Railway's caching system
- Keep build artifacts small (use standalone Next.js output)
- Avoid npm cache conflicts

## Specific Files to Fix

### `/src/lib/db.ts`
**Current Issues:**
- No retry logic for database connection
- Synchronous initialization that can crash on import
- No connection health checking

**Requirements:**
- Add connection retry with exponential backoff
- Export both sync and async versions
- Add connection health check method

### `/src/app/api/health/route.ts`
**Current Issues:**
- Creates new PrismaClient instead of using singleton
- Doesn't handle startup grace period properly
- Poor error handling for optional services

**Requirements:**
- Use the singleton Prisma client
- Return 200 during startup (first 60s) even if services aren't ready
- Check connection health without creating new connections

### `/src/lib/redis.ts`
**Current Issues:**
- The exported redis client might be null but health check doesn't handle this well

**Requirements:**
- Add a safe ping method that returns status instead of throwing
- Ensure optional nature is preserved

### `/src/lib/env.ts`
**Current Issues:**
- Validates environment variables on import
- Can crash the build/startup process

**Requirements:**
- Move validation to runtime
- Support graceful degradation
- Allow build to complete without all variables

### `/server.js`
**Current Issues:**
- Basic error handling
- No health check for server readiness

**Requirements:**
- Add server readiness tracking
- Improve error handling and recovery

### `/Dockerfile`
**Current Issues:**
- Might conflict with Railway's cache mounts

**Requirements:**
- Ensure no cache directories are used
- Use multi-stage build efficiently
- Include all necessary files in final stage

## Testing Your Changes
Your fixes should ensure:
1. The app builds successfully on Railway
2. Health checks pass within the timeout period
3. The app handles database connection delays gracefully
4. Redis being unavailable doesn't crash the app
5. The app can recover from temporary connection failures

## Additional Context
- Railway automatically injects a PORT environment variable
- Railway provides PostgreSQL via connection string reference: `${{Postgres.DATABASE_URL}}`
- The app should start serving requests even if some services aren't ready
- Health checks are critical for Railway to mark the deployment as successful

## Constraints
- Don't remove any existing functionality
- Maintain backward compatibility
- Keep changes minimal and focused on deployment issues
- Preserve the existing architecture patterns
- Don't add new dependencies unless absolutely necessary

Remember: The goal is to make the deployment resilient and able to handle the realities of cloud deployment where services might not be immediately available.